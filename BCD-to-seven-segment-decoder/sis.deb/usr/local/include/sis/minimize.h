/*
 * Revision Control Information
 *
 * $Source: /users/pchong/CVS/sis/sis/minimize/minimize.h,v $
 * $Author: pchong $
 * $Revision: 1.1.1.1 $
 * $Date: 2004/02/07 10:14:32 $
 *
 */
#define NOCOMP		0
#define SNOCOMP		1
#define	DCSIMPLIFY	2

#ifndef MINIMIZE_H
#define MINIMIZE_H

EXTERN pcover minimize ARGS((pcover, pcover, int));

#endif

